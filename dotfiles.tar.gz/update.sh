#!/bin/bash

export SRC_URL=${SRC_URL-https://raw.githubusercontent.com/rgeary1/terminalenv/refs/heads/main}

set -eu

# Options are passed through to install.sh
for arg in "$@"; do
  case $arg in
    -n|-y|--assume-yes|--skip-different) ;;
    -h|--help) echo "Usage: $0 [-n] [-y|--assume-yes] [--skip-different]"; exit 0 ;;
    *) echo "Unknown option: $arg"; exit 1 ;;
  esac
done

# Validation
if [[ ! -d $HOME || ! -w $HOME ]]; then
    echo 'No writeable $HOME'
    exit 1
fi
export SRCDIR="${SRCDIR-$HOME}/.dotfiles"

echo "Updating to $SRCDIR"
mkdir -p "$SRCDIR"

CB="?$(date +%s)"

# Try downloading the tarball from raw GitHub
tarball="$SRCDIR/dotfiles.tar.gz"
if curl -sfL "$SRC_URL/dotfiles.tar.gz${CB}" -o "$tarball"; then
  echo "Extracting dotfiles.tar.gz"
  tar -xzf "$tarball" -C "$SRCDIR"
  rm -f "$tarball"
else
  # Fallback: download files individually from raw GitHub
  echo "No tarball found, falling back to individual file downloads"
  for f in filelist symlinks install.sh diff.sh update.sh; do
    echo "curl -s $SRC_URL/dotfiles/$f -o $SRCDIR/$f"
    curl -s "$SRC_URL/dotfiles/${f}${CB}" -o "$SRCDIR/$f"
  done

  for f in $(cat $SRCDIR/filelist); do
    dir=$(dirname "$f")
    mkdir -p "$SRCDIR/$dir"
    # symlinks has "<path> <target>" per line
    target=$(awk -v f="$f" '$1 == f {print $2}' "$SRCDIR/symlinks" 2>/dev/null || true)
    if [[ -n $target ]]; then
      echo ln -sfn "$target" "$SRCDIR/$f"
      rm -f "$SRCDIR/$f"
      ln -sfn "$target" "$SRCDIR/$f"
      continue
    fi
    echo curl -s $SRC_URL/dotfiles/$f -o "$SRCDIR/$f"
    curl -s "$SRC_URL/dotfiles/${f}${CB}" -o "$SRCDIR/$f" || echo "Failed to copy $f"
  done
fi

chmod +x "$SRCDIR/update.sh" "$SRCDIR/install.sh" "$SRCDIR/diff.sh" "$SRCDIR/.lessfilter"

if [[ -e /usr/bin/gsettings ]]; then
  # Disable Ctrl+Alt+{Up,Down}; suppress errors when no dbus session is available
  for n in down up left right last; do
    gsettings set org.gnome.desktop.wm.keybindings switch-to-workspace-${n} "[]" 2>/dev/null || true
    gsettings set org.gnome.desktop.wm.keybindings move-to-workspace-${n} "[]" 2>/dev/null || true
  done
fi

# Install the files
"$SRCDIR/install.sh" "$@"
